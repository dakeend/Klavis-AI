"""Credential classes used to perform authenticated interactions with GitHub"""

from typing import Optional
from urllib.parse import urlparse, urlunparse

from pydantic import Field, SecretStr
from sgqlc.endpoint.http import HTTPEndpoint

from prefect.blocks.abstract import CredentialsBlock


class GitHubCredentials(CredentialsBlock):
    """
    Block used to manage GitHub authentication.

    Attributes:
        token: the token to authenticate into GitHub.

    Examples:
        Load stored GitHub credentials:
        ```python
        from prefect_github import GitHubCredentials
        github_credentials_block = GitHubCredentials.load("BLOCK_NAME")
        ```
    """

    _block_type_name = "GitHub Credentials"
    _logo_url = "https://raw.githubusercontent.com/PrefectHQ/prefect/420d0d6a78bb6df1fc18bcf188fdad43c1d22ea9/assets/block-logos/github.png"  # noqa
    _documentation_url = "https://docs.prefect.io/integrations/prefect-github"

    token: Optional[SecretStr] = Field(
        default=None, description="A GitHub personal access token (PAT)."
    )

    def format_git_credentials(self, url: str) -> str:
        """
        Format and return the full git URL with GitHub credentials embedded.

        GitHub uses plain token format without any prefix.

        Args:
            url: Repository URL (e.g., "https://github.com/org/repo.git")

        Returns:
            Complete URL with credentials embedded

        Raises:
            ValueError: If token is not configured
        """
        if not self.token:
            raise ValueError("Token is required for GitHub authentication")

        # Insert token into URL
        parsed = urlparse(url)
        credentials = self.token.get_secret_value()
        return urlunparse(parsed._replace(netloc=f"{credentials}@{parsed.netloc}"))

    def get_client(self) -> HTTPEndpoint:
        """
        Gets an authenticated GitHub GraphQL HTTPEndpoint client.

        Returns:
            An authenticated GitHub GraphQL HTTPEndpoint client.

        Example:
            Gets an authenticated GitHub GraphQL HTTPEndpoint client.
            ```python
            from prefect_github import GitHubCredentials

            github_credentials = GitHubCredentials(token=token)
            client = github_credentials.get_client()
            ```
        """

        if self.token is not None:
            base_headers = {"Authorization": f"Bearer {self.token.get_secret_value()}"}
        else:
            base_headers = None

        endpoint = HTTPEndpoint(
            "https://api.github.com/graphql", base_headers=base_headers
        )
        return endpoint
